const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const session = require('express-session');

let { ObjectId } = require('mongodb');
let db = require('./database.js');

const path = require('path');


app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));
app.set('view engine', 'ejs');



app.use(session({secret: "node_mongo123!@#", resave:true, saveUninitialized: true}));
app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({extended:true}));



        // Login
        app.get('/', (req, res) => {
            res.render('login');
        });

        app.post('/login', (req, res) => {
			const { username, password } = req.body;
			db.collection('admin').findOne({ username, password })
			.then(user => {
            if (user) {
                req.session.user = user;
                res.redirect('/dashboard');
            } else {
                res.render('login', { error: 'Invalid username or password, please try again' });
            }
        })
        .catch(err => {
            console.error(err);
            res.render('login', { error: 'An error occurred, please try again' });
        });
});
		//Dashboard
        app.get('/dashboard', (req, res) => {
            if (req.session.user) {
                res.render('dashboard');
            } else {
                res.redirect('/');
            }
        });

        //Students
        app.get('/students', (req, res) => {
            db.collection('Student').find().toArray()
                .then(results => res.render('students', { students: results }));
        });

        app.post('/students/add', (req, res) => {
            db.collection('Student').insertOne(req.body)
                .then(() => res.redirect('/students'));
        });

        app.post('/students/delete/:id', (req, res) => {
            const { id } = req.params;
            db.collection('Student').deleteOne({ student_id: id })
                .then(() => res.redirect('/students'));
        });
		// Edit form for a student
		app.get('/students/edit/:id', (req, res) => {
			const { id } = req.params;
			db.collection('Student').findOne({ student_id: id })
				.then(student => {
					if (student) {
						res.render('edit_student', { student });
					} else {
						res.redirect('/students');
					}
				});
		});

		//Update Student
		app.post('/students/edit/:id', (req, res) => {
			const { id } = req.params;
			const updatedStudent = {
				student_id: req.body.student_id,
				name: req.body.name,
				email: req.body.email,
				phone_no: req.body.phone_no,
				department: req.body.department,
				session: req.body.session,
				student_status: req.body.student_status
			};
			db.collection('Student').updateOne({ student_id: id }, { $set: updatedStudent })
				.then(() => res.redirect('/students'));
		});

		

        // Books
        app.get('/books', (req, res) => {
            db.collection('Books').find().toArray()
                .then(results => res.render('books', { books: results }));
        });

        app.post('/books/add', (req, res) => {
            db.collection('Books').insertOne(req.body)
                .then(() => res.redirect('/books'));
        });

        app.post('/books/delete/:id', (req, res) => {
            const { id } = req.params;
            db.collection('Books').deleteOne({ book_id: id })
                .then(() => res.redirect('/books'));
        });
		// Edit form for a book
		app.get('/books/edit/:id', (req, res) => {
			const { id } = req.params;
			db.collection('Books').findOne({ book_id: id })
				.then(book => {
					if (book) {
						res.render('edit_book', { book });
					} else {
						res.redirect('/books');
					}
				});
		});

		// Update Book
		app.post('/books/edit/:id', (req, res) => {
			const { id } = req.params;
			const updatedBook = {
				book_id: req.body.book_id,
				title: req.body.title,
				author: req.body.author,
				language: req.body.language,
				cat_id: req.body.cat_id,
				price: req.body.price,
				total_copies: req.body.total_copies,
				available_copies: req.body.available_copies,
				book_status: req.body.book_status
			};
			db.collection('Books').updateOne({ book_id: id }, { $set: updatedBook })
				.then(() => res.redirect('/books'));
		});


        // Borrowing
        app.get('/borrow', (req, res) => {
            db.collection('Borrow').find().toArray()
                .then(results => res.render('borrow', { borrow: results }));
        });

        app.post('/borrow/add', (req, res) => {
            db.collection('Borrow').insertOne(req.body)
                .then(() => res.redirect('/borrow'));
        });
		app.post('/borrow/delete/:id', (req, res) => { 
            const { id } = req.params;
            db.collection('Borrow').deleteOne({ borrow_id: id })
                .then(() => res.redirect('/borrow'));
        });
		// Edit form for a borrowed book
		app.get('/borrow/edit/:id', (req, res) => {
			const { id } = req.params;
			db.collection('Borrow').findOne({ borrow_id: id })
				.then(borrow => {
					if (borrow) {
						res.render('edit_borrow', { borrow });
				} else {
					res.redirect('/borrow');
				}
			});
		});

		// Update Borrowing
		app.post('/borrow/edit/:id', (req, res) => {
			const { id } = req.params;
			const updatedBorrow = {
				borrow_id: req.body.borrow_id,
				student_id: req.body.student_id,
				book_id: req.body.book_id,
				issue_date: req.body.issue_date,
				due_date: req.body.due_date
			};
			db.collection('Borrow').updateOne({ borrow_id: id }, { $set: updatedBorrow })
				.then(() => res.redirect('/borrow'));
		});


        // Returning
        app.get('/return', (req, res) => {
            db.collection('Return').find().toArray()
                .then(results => res.render('return', { returns: results }));
        });

        app.post('/return/add', (req, res) => {
            db.collection('Return').insertOne(req.body)
                .then(() => res.redirect('/return'));
        });
		app.post('/return/delete/:id', (req, res) => {
            const { id } = req.params;
            db.collection('Return').deleteOne({ borrow_id: id })
                .then(() => res.redirect('/return'));
        });
		// Edit form for a returned book
		app.get('/return/edit/:id', (req, res) => {
			const { id } = req.params;
			db.collection('Return').findOne({ borrow_id: id })
				.then(returnedBook => {
					if (returnedBook) {
						res.render('edit_return', { returnedBook });
					} else {
						res.redirect('/return');
					}
				});
		});

		// Update Returned book
		app.post('/return/edit/:id', (req, res) => {
			const { id } = req.params;
			const updatedReturn = {
				borrow_id: req.body.borrow_id,
				student_id: req.body.student_id,
				book_id: req.body.book_id,
				return_date: req.body.return_date,
				due_date: req.body.due_date,
				fine: req.body.fine,
				return_status: req.body.return_status,
				fine_status: req.body.fine_status
			};
			db.collection('Return').updateOne({ borrow_id: id }, { $set: updatedReturn })
				.then(() => res.redirect('/return'));
		});


        // Category
        app.get('/categories', (req, res) => {
            db.collection('Category').find().toArray()
                .then(results => res.render('categories', { categories: results }));
        });

        app.post('/categories/add', (req, res) => {
            db.collection('Category').insertOne(req.body)
                .then(() => res.redirect('/categories'));
        });

        app.post('/categories/delete/:id', (req, res) => {
            const { id } = req.params;
            db.collection('Category').deleteOne({ cat_id: id })
                .then(() => res.redirect('/categories'));
        });
		//Edit form for a category
		app.get('/categories/edit/:id', (req, res) => {
			const { id } = req.params;
			db.collection('Category').findOne({ cat_id: id })
				.then(category => {
					if (category) {
						res.render('edit_category', { category });
					} else {
						res.redirect('/categories');
					}
				});
		});

		// Update Category
		app.post('/categories/edit/:id', (req, res) => {
			const { id } = req.params;
			const updatedCategory = {
				cat_id: req.body.cat_id,
				name: req.body.name
			};
			db.collection('Category').updateOne({ cat_id: id }, { $set: updatedCategory })
				.then(() => res.redirect('/categories'));
		});


        app.get('/logout', (req, res) => {
            req.session.destroy();
            res.redirect('/');
        });

        app.listen(8080, () => {
            console.log('Server is running on port 8080');
        });